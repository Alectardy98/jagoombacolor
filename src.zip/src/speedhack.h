#ifndef __SPEEDHACK_H__
#define __SPEEDHACK_H__

void find_speedhacks(void);


#endif
