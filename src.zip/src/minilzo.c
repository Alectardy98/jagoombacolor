#include "config.h"

#define LZO_NO_SYS_TYPES_H

#if CARTSRAM
#include "minilzo.107/minilzo.c"
#endif
