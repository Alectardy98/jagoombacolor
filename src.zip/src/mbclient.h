#ifndef __MBCLIENT_H__
#define __MBCLIENT_H__

int SendMBImageToClient(void);

#endif
