	@IMPORT _E0
	@IMPORT _E2
	@IMPORT _F0
	@IMPORT _F2


	@IMPORT thumbcall_r1
	@IMPORT IO_reset
	@IMPORT IO_R
	@IMPORT IO_High_R
	@IMPORT IO_W
	@IMPORT IO_High_W
	@IMPORT joypad_write_ptr
	@IMPORT joy0_W
	@IMPORT suspend
	@IMPORT gettime
	@IMPORT refreshNESjoypads
	@IMPORT serialinterrupt
	@IMPORT _FF70W
	@IMPORT FF41_R_ptr
	@IMPORT FF44_R_ptr

	@IMPORT io_read_tbl
	@IMPORT io_write_tbl

	@.end
