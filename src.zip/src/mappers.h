	@IMPORT mbc0init
	@IMPORT mbc1init
	@IMPORT mbc2init
	@IMPORT mbc3init
	@IMPORT mbc4init
	@IMPORT mbc5init
	@IMPORT mbc6init
	@IMPORT mbc7init
	@IMPORT mmm01init
	@IMPORT huc1init
	@IMPORT huc3init
	@.end
