	@IMPORT void
	@IMPORT empty_R
	@IMPORT empty_W
	@IMPORT mem_R00
	@IMPORT mem_R20
	@IMPORT mem_R40
	@IMPORT mem_R60
	@IMPORT mem_R80
	@IMPORT mem_RA0
	@IMPORT mem_RC0
	@IMPORT mem_RC0_2
	@IMPORT sram_W
	@IMPORT sram_W2
	@IMPORT wram_W
	@IMPORT wram_W_2
	@IMPORT echo_W
	@IMPORT echo_R
	
	@IMPORT memset32_
	@IMPORT memcpy32_
	@IMPORT memset32
	@IMPORT memcpy32
	@.end
