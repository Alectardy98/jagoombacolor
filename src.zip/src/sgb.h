	@IMPORT joy0_W_SGB
	@IMPORT joy0_R_SGB
	@IMPORT g_update_border_palette
	@IMPORT sgb_reset
	@IMPORT g_sgb_mask
	@.end
